﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //пРАВКА, ЕСЛИ НАЖАТЬ КРЕСТИК
        private void ChildForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Сохранить Файл?", "Выход", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Form1 childForm = (Form1)this.ActiveMdiChild;
                saveFileDialog1.Filter = "Rich Text File|*.rtf";
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    childForm.richTextBox1.SaveFile(saveFileDialog1.FileName);
                    childForm.Text = saveFileDialog1.FileName;
                }
            }
        }

        private void выделитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
