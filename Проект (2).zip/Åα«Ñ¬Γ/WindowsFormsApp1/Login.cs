﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            Load();
            textBox2.UseSystemPasswordChar = true;


        }
        
        //КЛАСС ТЕКСТОВОГО ФАЙЛА
        public class data
        {
            public static string FileUser = ("Dor.txt");
            public static List<User> Users;
            public static string Login { get; set; }
            public static string Password { get; set; }

            public static string ser()
            {
                string text = "";
                foreach (var user in data.Users)
                {
                    text += $"{user.Login}:{user.Password}\n";
                }
                return text;
            }
        }
        //СЧИТЫВАНИЕ ДАННЫХ В ФАЙЛЕ
        public static void Load()
        {
            var Text = File.ReadAllText(data.FileUser);
            var users = new List<User>();

            using (StreamReader red = new StreamReader(data.FileUser))
            {
                string line = "";
                while ((line = red.ReadLine()) != null)
                {
                    string[] data = line.Split(':');
                    users.Add(new User(data[0], data[1]));
                }
            }

            data.Users = users;
        }

        //ПРОВЕРКА ПАРОЛЕЙ
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //у МЕНЯ НЕТ АККАУЕНТА
        private void button3_Click(object sender, EventArgs e)
        {
            Registr newForm = new Registr();
            newForm.Show();
            Close();
        }
        //ЗАКРЫТИЕ 
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_BackColorChanged(object sender, EventArgs e)
        {

        }
        //КЛАСС ПОЛЬЗОВАТЕЛЯ
        public class User
        {
            public string Login { get; set; }
            public string Password { get; set; }
            public User(string login, string password)
            {
                this.Login = login;
                this.Password = password;
            }

        }
        //ВХОД В АККАУНТ И ОТКРЫТИЕ КНОПОК ФАЙЛА И ВЫХОЖДЕНИЯ
        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var user in data.Users)
            {
                if (user.Login == textBox1.Text && user.Password == textBox2.Text)
                {
                    data.Login = textBox1.Text;
                    data.Password = textBox2.Text;
                    Main form1 = Application.OpenForms.OfType<Main>().FirstOrDefault();
                    if (form1 != null)
                    {
                        form1.Login.Enabled = false;
                        form1.reg.Enabled = false;
                        form1.Exit.Enabled = true;
                        form1.MyMenuItem.Enabled = true;
                    }
                    MessageBox.Show("Вы вошли");
                    this.Close();

                    this.Hide();

                }
               
            }
        }
       
        //рЕЖИМ ГОСТЯ
        private void button4_Click(object sender, EventArgs e)
        {
            Main form1 = Application.OpenForms.OfType<Main>().FirstOrDefault();
            if (form1 != null)
            {
                form1.MyMenuItem.Enabled = false;
            }
            MessageBox.Show("Режим гостя!");
            this.Close();
        }
    }
}
